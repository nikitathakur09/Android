package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText a;
    EditText b;
    TextView r;
    Button p;
    Button s;
    Button m;
    Button d;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        a=(EditText)findViewById(R.id.editText);
        b=(EditText)findViewById(R.id.editText2);
        r=(TextView) findViewById(R.id.textView);
        p=(Button) findViewById(R.id.button);
        s=(Button) findViewById(R.id.button2);
        m=(Button) findViewById(R.id.button3);
        d=(Button) findViewById(R.id.button4);

        p.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                String s1 = a.getText().toString();
                String s2 = b.getText().toString();
                if (TextUtils.isEmpty(s1) & TextUtils.isEmpty(s2)) {
                    Toast.makeText(MainActivity.this, "Enter a number", Toast.LENGTH_LONG).show();
                } else {
                    int n1 = Integer.parseInt(s1);
                    int n2 = Integer.parseInt(s2);
                    r.setText(n1 + n2 + "");
                }
            }
        });

        s.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                String s1 = a.getText().toString();
                String s2 = b.getText().toString();
                if (TextUtils.isEmpty(s1) & TextUtils.isEmpty(s2)) {
                    Toast.makeText(MainActivity.this, "Enter a number", Toast.LENGTH_LONG).show();
                } else {
                    int n1 = Integer.parseInt(s1);
                    int n2 = Integer.parseInt(s2);
                    r.setText(n1 - n2 + "");
                }
            }
        });

        m.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                String s1 = a.getText().toString();
                String s2 = b.getText().toString();
                if (TextUtils.isEmpty(s1) & TextUtils.isEmpty(s2)) {
                    Toast.makeText(MainActivity.this, "Enter a number", Toast.LENGTH_LONG).show();
                } else {
                    int n1 = Integer.parseInt(s1);
                    int n2 = Integer.parseInt(s2);
                    r.setText(n1 * n2 + "");
                }
            }
        });

        d.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                String s1 = a.getText().toString();
                String s2 = b.getText().toString();
                if (TextUtils.isEmpty(s1) & TextUtils.isEmpty(s2)) {
                    Toast.makeText(MainActivity.this, "Enter a number", Toast.LENGTH_LONG).show();
                } else {
                    int n1 = Integer.parseInt(s1);
                    int n2 = Integer.parseInt(s2);
                    r.setText(n1 / n2 + "");
                }
            }
        });
    };
};